This release includes FOTA update from mfw_nrf9160_1.2.0 release to mfw_nrf9160_1.2.1 release.
FOTA update filename is mfw_nrf9160_update_from_1.2.0_to_1.2.1.bin.

This release includes FOTA-TEST images between mfw_nrf9160_1.2.1 release and mfw_nrf9160_1.2.1-FOTA-TEST image.
FOTA test update filenames are mfw_nrf9160_update_from_1.2.1_to_1.2.1-FOTA-TEST and mfw_nrf9160_update_from_1.2.1-FOTA-TEST_to_1.2.1.

UUID of mfw_nrf9160_1.2.1 is 153962e1-c804-419d-847f-bf104170fc80
UUID of mfw_nrf9160_1.2.1-FOTA-TEST is 38fac0bc-b7cf-4adc-a40e-f43582693a71